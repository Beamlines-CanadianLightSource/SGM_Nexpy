from __future__ import absolute_import
from . import map_plot, xas_plot, xas_multi

def plugin_menu():
    menu = 'SGMPy'
    actions = []
    actions.append(('Single XAS', xas_plot.show_dialog))
    actions.append(('Multi XAS', xas_multi.show_dialog))
    actions.append(('Plot Map', map_plot.show_dialog))
    return menu, actions
